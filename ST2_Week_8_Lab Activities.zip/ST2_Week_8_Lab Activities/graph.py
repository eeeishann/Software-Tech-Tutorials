class Graph:
    def __init__(self, directed=False, weighted=False):
        self.graph = {}  # Initialize an empty dictionary to store the adjacency list
        self.weights = {}
        self.directed = directed
        self.weighted = weighted

    def add_vertex(self, vertex):
        if vertex not in self.graph:
            self.graph[vertex] = []  # Add a new vertex with an empty list of edges

    def add_edge(self, vertex1, vertex2, weight=0):
        if vertex1 in self.graph and vertex2 in self.graph: # Check that vertices are present
            # store vertex and weight as a tuple
            self.graph[vertex1].append(vertex2)
            if self.weighted:
                self.weights[(vertex1, vertex2)] = weight
            if not self.directed: # In the case of an undirected graph, append in both directions
                self.graph[vertex2].append(vertex1)
                if self.weighted:
                    self.weights[(vertex2, vertex1)] = weight
        else:
            print("One or both vertices not found in graph.")

    def print_graph(self):
        for vertex in self.graph:
            print(f"{vertex} -> ", end="")

            for neighbor in self.graph[vertex]:
                if self.weighted:
                    weight = self.weights.get((vertex, neighbor), 0)
                    print(f"{neighbor}({weight}) ", end="")
                else:
                    print(f"{neighbor} ", end="")

            print()


    def remove_edge(self, vertex1, vertex2):
        if vertex1 in self.graph and vertex2 in self.graph:
            if vertex2 in self.graph[vertex1]:
                self.graph[vertex1].remove(vertex2)
                if self.weighted:
                    self.weights.pop((vertex1, vertex2), None)

            if not self.directed:
                if vertex1 in self.graph[vertex2]:
                    self.graph[vertex2].remove(vertex1)
                    if self.weighted:
                        self.weights.pop((vertex2, vertex1), None)
        else:
            print("One or both vertices not found.")


    def remove_vertex(self, vertex):
        if vertex in self.graph:
            # Remove all edges pointing TO this vertex
            for v in self.graph:
                if vertex in self.graph[v]:
                    self.graph[v].remove(vertex)
                    if self.weighted:
                        self.weights.pop((v, vertex), None)


            if self.weighted:
                for neighbor in self.graph[vertex]:
                    self.weights.pop((vertex, neighbor), None)

            # Finally remove the vertex
            del self.graph[vertex]
        else:
            print("Vertex not found.")

    def bfs(self, start_vertex):
        if start_vertex not in self.graph:
            print("Start vertex not in graph.")
            return []

        visited = []  # list to store visited vertices in order
        queue = [start_vertex]  # BFS queue

        while queue:
            vertex = queue.pop(0)  # dequeue
            if vertex not in visited:
                visited.append(vertex)
                # enqueue all unvisited neighbors
                for neighbor in self.graph[vertex]:
                    if neighbor not in visited and neighbor not in queue:
                        queue.append(neighbor)
        return visited

    def dfs(self, start_vertex):
        if start_vertex not in self.graph:
            print("Start vertex not in graph.")
            return []

        visited = []
        stack = [start_vertex]

        while stack:
            vertex = stack.pop()  # pop from the end (LIFO)
            if vertex not in visited:
                visited.append(vertex)
                # Add neighbors to stack in reverse order to maintain natural order
                for neighbor in reversed(self.graph[vertex]):
                    if neighbor not in visited and neighbor not in stack:
                        stack.append(neighbor)

        return visited


    def _has_cycle_util(self, vertex, visited, parent):
        visited.add(vertex)
        for neighbor in self.graph[vertex]:
            if neighbor not in visited:
                if self._has_cycle_util(neighbor, visited, vertex):
                    return True
            elif neighbor != parent:
                # Found a back edge to a visited vertex not the parent → cycle
                return True
        return False


    def has_undirected_cycle(self):
        if self.directed:
            print("This method is only for undirected graphs.")
            return False

        visited = set()
        for vertex in self.graph:
            if vertex not in visited:
                if self._has_cycle_util(vertex, visited, None):
                    return True
        return False




