from graph import Graph

# Basic undirected graph tests
print("Undirected graph test")
g = Graph()

g.add_vertex('A')
g.add_vertex('B')
g.add_vertex('C')
g.add_vertex('D')

g.add_edge('A', 'B')
g.add_edge('B', 'C')

g.print_graph()
print()

# Directed graph tests
print("Directed graph test")
g = Graph(directed=True)

g.add_vertex('A')
g.add_vertex('B')
g.add_vertex('C')
g.add_vertex('D')

g.add_edge('A', 'B')
g.add_edge('B', 'C')

g.print_graph()
print()

# Weighted graph tests
print("Weighted graph test")
g = Graph(weighted=True, directed=True)

g.add_vertex('A')
g.add_vertex('B')
g.add_vertex('C')
g.add_vertex('D')

g.add_edge('A', 'B', 15)
g.add_edge('B', 'C', 34)

g.print_graph()

# Removal tests
print()
print("Removal test")
removal_test = Graph()

removal_test.add_vertex('A')
removal_test.add_vertex('B')
removal_test.add_vertex('C')
removal_test.add_vertex('D')

removal_test.add_edge('A', 'B')
removal_test.add_edge('B', 'C')

removal_test.print_graph()

removal_test.remove_edge('A', 'B')
removal_test.print_graph()

removal_test.remove_vertex('C')
removal_test.print_graph()

print()

# Create weighted directed graph
wg = Graph(directed=True, weighted=True)
for v in ['A', 'B', 'C']:
    wg.add_vertex(v)
wg.add_edge('A', 'B', weight=15)
wg.add_edge('B', 'C', weight=34)
wg.add_edge('A', 'C', weight=50)
print("Weighted Directed Graph:")
wg.print_graph()
